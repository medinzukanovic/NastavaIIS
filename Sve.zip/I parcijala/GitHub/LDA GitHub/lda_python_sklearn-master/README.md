# lda_python_sklearn
Using sklearn and python to impelement lda algorithm 
