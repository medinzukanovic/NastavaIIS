# LDA
An implementation of Linear Discriminant Analysis on multi-class speaker recognition. Written in Python. 






