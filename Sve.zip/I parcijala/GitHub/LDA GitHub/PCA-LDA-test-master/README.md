# PCA-LDA-test
Testing SKLearn PCA and LDA
