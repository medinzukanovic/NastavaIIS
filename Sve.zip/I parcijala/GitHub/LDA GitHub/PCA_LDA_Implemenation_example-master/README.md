# PCA_LDA_Implemenation_example
For beginners how to apply PCA and LDA methods using sklearn
