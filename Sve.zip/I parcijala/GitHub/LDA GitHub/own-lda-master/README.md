# own-lda
Own Linear Discriminant Analysis without using sklearn. Eigenvalues approach is used in this program.

Generalized LDA function is available. A demo with iris data is presented but this function can be used with any data.
The output results will match with Sklearn's LDA with eigenvalues solver.

Visit my portfolio or reach me out for questions at - 
www.mithunjmistry.com
