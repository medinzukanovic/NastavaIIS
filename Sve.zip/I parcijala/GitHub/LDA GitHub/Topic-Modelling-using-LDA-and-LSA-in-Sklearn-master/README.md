/*

    Author:: Raj Mehrotra
    Date:: 09-01-2019
    
 */

# Topic-Modelling-using-LDA-and-LSA-in-Sklearn

Topic modelling is done on the dataset : **"A Million News Headlines"** on the kaggle. 

I have first pre-processed and cleaned the data. 

Then I have used the implementations of the LDA and the LSA in the sklearn library.

Also the distribution of words in a topic is shown.
