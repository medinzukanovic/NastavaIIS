import numpy as np
target=np.zeros(79)
target[:51]=1
target[51:]=2
print(target)