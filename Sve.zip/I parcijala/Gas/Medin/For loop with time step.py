import time
#Odakle, dokle, korak
for i in range (10,31,10):
    print(i)
    time.sleep(1)